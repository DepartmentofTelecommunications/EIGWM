class CMRItem{
    constructor(url, noOfGranules){
        this.url = url;
        this.noOfGranules = noOfGranules;
        return this;
    }
}