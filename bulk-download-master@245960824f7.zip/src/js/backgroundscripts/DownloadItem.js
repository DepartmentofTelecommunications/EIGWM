class DownloadItem{
    constructor(url){
        this.url = url;
        this.id = null;
        return this;
    }
}